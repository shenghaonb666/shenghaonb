chmod +x 自动写配置.py

chmod +x 1.py

chmod +x 音乐.py

chmod +x 自动语音包.py

chmod +x 衣服dat.py

chmod +x 伪实体.py

chmod +x 偷普通美化配置.py

chmod +x 水印.py

chmod +x 品质.py

chmod +x uexp解包.py

chmod +x uexp打包.py

chmod +x dat解包.sh

chmod +x dat打包.sh

chmod +x yusheng/quickbms

chmod +x yusheng/打包.bms

chmod +x yusheng/解包.bms